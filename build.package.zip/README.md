This is an interactive personal website, made in babylon.js, and inspired by Bruno Simon.
The website is still under developement: https://setin2.github.io/stefan-cernat/
